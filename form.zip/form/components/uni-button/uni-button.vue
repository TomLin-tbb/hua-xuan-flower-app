<template>
  <view class="uni-button" @click="handleClick">
    <slot></slot>
  </view>
</template>

<script>
export default {
  name: "uni-button",
  methods: {
    handleClick() {
      this.$emit("click");
    },
  },
};
</script>

<style scoped>
.uni-button {
  padding: 10px 20px;
  background-color: #007AFF;
  color: #FFFFFF;
  border-radius: 5px;
  text-align: center;
  cursor: pointer;
}
</style>