// 新增花卉记录
exports.main = async (event, context) => {
  const db = uniCloud.database() // 获取数据库实例
  try {
    // 向info表添加数据（event.formData是前端传递的表单数据）
    const res = await db.collection('info').add(event.formData)
    return {
      success: true,
      data: res // 返回新增结果（包含_id等信息）
    }
  } catch (err) {
    return {
      success: false,
      errMsg: err.message // 错误信息
    }
  }
}