// 修改花卉记录
exports.main = async (event, context) => {
  const db = uniCloud.database()
  try {
    // 根据id（event.id）更新记录，数据为event.formData
    const res = await db.collection('info').doc(event.id).update(event.formData)
    return {
      success: true,
      data: res // 返回修改结果
    }
  } catch (err) {
    return {
      success: false,
      errMsg: err.message
    }
  }
}