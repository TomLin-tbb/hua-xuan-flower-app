// 查询所有花卉记录
exports.main = async (event, context) => {
  const db = uniCloud.database()
  try {
    // 查询info表所有数据
    const res = await db.collection('info').get()
    return {
      success: true,
      data: res.data // 返回查询到的数组
    }
  } catch (err) {
    return {
      success: false,
      errMsg: err.message
    }
  }
}