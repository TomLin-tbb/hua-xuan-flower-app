// 根据ID查询单个花卉记录
exports.main = async (event, context) => {
  const db = uniCloud.database()
  try {
    // 根据前端传递的id（event.id）查询单条记录
    const res = await db.collection('info').doc(event.id).get()
    return {
      success: true,
      data: res.data[0] // 返回单条记录（数组第一个元素）
    }
  } catch (err) {
    return {
      success: false,
      errMsg: err.message
    }
  }
}