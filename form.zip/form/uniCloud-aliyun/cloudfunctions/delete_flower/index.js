// 删除花卉记录
exports.main = async (event, context) => {
  const db = uniCloud.database()
  try {
    // 根据id（event.id）删除记录
    const res = await db.collection('info').doc(event.id).remove()
    return {
      success: true,
      data: res // 返回删除结果
    }
  } catch (err) {
    return {
      success: false,
      errMsg: err.message
    }
  }
}